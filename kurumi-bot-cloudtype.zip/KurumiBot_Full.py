import discord
from discord.ext import commands, tasks
import sqlite3
import os
from datetime import datetime, timedelta

# ─── 설정 ──────────────────────────────────────
TOKEN = "YOUR_DISCORD_BOT_TOKEN"
PREFIX = "쿠루미 "
DB_NAME = 'kurumi.db'
JOIN_WINDOW = 10
MAX_JOINS = 5

intents = discord.Intents.all()
bot = commands.Bot(command_prefix=PREFIX, intents=intents)
recent_joins = {}

# ─── DB 초기화 ──────────────────────────────────
def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS warnings (
        user_id INTEGER,
        guild_id INTEGER,
        reason TEXT,
        timestamp TEXT
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS joins (
        user_id INTEGER,
        guild_id INTEGER,
        join_time TEXT
    )""")
    conn.commit()
    conn.close()

def add_warning(user_id, guild_id, reason, timestamp):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO warnings VALUES (?, ?, ?, ?)", (user_id, guild_id, reason, timestamp))
    conn.commit()
    conn.close()

def get_warnings(user_id, guild_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM warnings WHERE user_id = ? AND guild_id = ?", (user_id, guild_id))
    results = c.fetchall()
    conn.close()
    return results

# ─── 기본 이벤트 ────────────────────────────────
@bot.event
async def on_ready():
    print(f"✅ 로그인됨: {bot.user}")
    await bot.change_presence(activity=discord.Game(name="쿠루미 지켜보는 중"))
    server_analysis.start()

# ─── 관리 명령어 ────────────────────────────────
@bot.command()
async def 경고(ctx, member: discord.Member, *, reason="사유 없음"):
    timestamp = datetime.utcnow().isoformat()
    add_warning(member.id, ctx.guild.id, reason, timestamp)
    await ctx.send(f"⚠️ {member.mention}에게 경고를 주었습니다. 사유: {reason}")

@bot.command()
async def 경고목록(ctx, member: discord.Member):
    warnings = get_warnings(member.id, ctx.guild.id)
    if not warnings:
        await ctx.send(f"{member.mention}은(는) 경고가 없습니다.")
    else:
        msg = "\n".join([f"- {w[2]} ({w[3]})" for w in warnings])
        await ctx.send(f"📋 {member.mention}의 경고 목록:\n{msg}")

@bot.command()
async def 킥(ctx, member: discord.Member, *, reason="사유 없음"):
    await member.kick(reason=reason)
    await ctx.send(f"👢 {member.mention}을(를) 킥했습니다. 사유: {reason}")

@bot.command()
async def 밴(ctx, member: discord.Member, *, reason="사유 없음"):
    await member.ban(reason=reason)
    await ctx.send(f"⛔ {member.mention}을(를) 밴했습니다. 사유: {reason}")

@bot.command()
async def 타임아웃(ctx, member: discord.Member, minutes: int, *, reason="사유 없음"):
    until = discord.utils.utcnow() + timedelta(minutes=minutes)
    await member.timeout(until, reason=reason)
    await ctx.send(f"⏱️ {member.mention}을(를) {minutes}분 타임아웃했습니다.")

# ─── 보안 기능 ─────────────────────────────────
@bot.event
async def on_member_join(member):
    now = datetime.utcnow()
    gid = member.guild.id
    recent_joins.setdefault(gid, []).append(now)
    recent_joins[gid] = [t for t in recent_joins[gid] if (now - t).total_seconds() <= JOIN_WINDOW]

    if len(recent_joins[gid]) > MAX_JOINS:
        channel = discord.utils.get(member.guild.text_channels, name="security-alerts")
        if channel:
            await channel.send("🚨 안티레이드 경고! 너무 많은 가입 발생!")

    welcome = discord.utils.get(member.guild.text_channels, name="welcome")
    if welcome:
        await welcome.send(f"🎉 {member.mention}님, 어서오세요!")

@bot.event
async def on_member_remove(member):
    farewell = discord.utils.get(member.guild.text_channels, name="farewell")
    if farewell:
        await farewell.send(f"👋 {member.mention}님이 떠났습니다.")

@bot.event
async def on_member_update(before, after):
    if before.nick != after.nick:
        channel = discord.utils.get(after.guild.text_channels, name="security-alerts")
        if channel:
            await channel.send(f"✏️ 닉네임 변경: `{before.nick}` → `{after.nick}`")

@bot.event
async def on_user_update(before, after):
    if before.avatar != after.avatar:
        for guild in bot.guilds:
            member = guild.get_member(after.id)
            if member:
                channel = discord.utils.get(guild.text_channels, name="security-alerts")
                if channel:
                    await channel.send(f"🖼️ {member.mention}의 프로필 사진이 변경되었습니다.")

# ─── 로그 기능 ─────────────────────────────────
@bot.event
async def on_message_delete(message):
    if message.author.bot:
        return
    channel = discord.utils.get(message.guild.text_channels, name="logs")
    if channel:
        await channel.send(f"🗑️ 삭제됨: {message.author} - `{message.content}`")

@bot.event
async def on_message_edit(before, after):
    if before.author.bot:
        return
    channel = discord.utils.get(before.guild.text_channels, name="logs")
    if channel:
        await channel.send(f"✏️ 수정됨: {before.author}\n이전: `{before.content}`\n이후: `{after.content}`")

@bot.event
async def on_command(ctx):
    channel = discord.utils.get(ctx.guild.text_channels, name="logs")
    if channel:
        await channel.send(f"⚙️ 명령어 사용: {ctx.author} - `{ctx.message.content}`")

# ─── 기본 반응 ────────────────────────────────
@bot.event
async def on_message(message):
    if message.author.bot:
        return
    if "쿠루미" in message.content:
        await message.channel.send("💬 네! 부르셨어요?")
    await bot.process_commands(message)

# ─── 주기적 서버 분석 ─────────────────────────
@tasks.loop(hours=24)
async def server_analysis():
    for guild in bot.guilds:
        channel = discord.utils.get(guild.text_channels, name="logs")
        if channel:
            await channel.send(f"🔍 서버 분석\n- 인원 수: {guild.member_count}")

# ─── 실행 ─────────────────────────────────────
if __name__ == "__main__":
    init_db()
    bot.run(TOKEN)